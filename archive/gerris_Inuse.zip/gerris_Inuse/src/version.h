/* version.h
 *
 * This is a generated file.  Please modify 'darcsversion.sh'
 */

#ifndef GFSVERSION_H
#define GFSVERSION_H

#define GFS_BUILD_VERSION "121021-165115"

#endif /* GFSVERSION_H */
