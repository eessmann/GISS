python -u test.py logo
