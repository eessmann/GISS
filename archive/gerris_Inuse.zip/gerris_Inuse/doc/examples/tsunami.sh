python -u test.py tsunami
