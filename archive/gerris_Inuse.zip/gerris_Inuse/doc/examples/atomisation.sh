python -u test.py atomisation
