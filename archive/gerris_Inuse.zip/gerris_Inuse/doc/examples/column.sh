python -u test.py column
