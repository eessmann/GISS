python -u test.py tangaroa
