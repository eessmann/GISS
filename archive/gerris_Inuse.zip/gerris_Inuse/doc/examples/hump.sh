python -u test.py hump
