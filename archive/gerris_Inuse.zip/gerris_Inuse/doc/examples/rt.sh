python -u test.py rt
