python -u test.py ship
